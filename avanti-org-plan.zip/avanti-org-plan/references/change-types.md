# Change Types — Worked Examples

Each section shows what to do for a common kind of update. The pattern is always the same: figure out which tab(s) own the change, update them, regenerate downstream views.

## RM override ("X now reports to Y")

**Example:** "AF867 Roopam now reports to Urvashi (was Namisha)"

1. **Decisions tab** — add a row:
   - Date, AF ID (AF867), Person name, Change type ("RM override"), From ("Namisha"), To ("Urvashi"), Rationale ("per user instruction"), Source ("conversation 2026-04-26")
2. **Employee Master (Final) tab** — find the AF867 row:
   - Update `Final RM (after corrections)` from "Namisha" to "Urvashi"
   - Leave `Original RM (Personnel sheet)` as the source-sheet value (audit trail)
   - Update `Changes Applied` to include "RM changed"
3. **org_chart.html** — regenerate. AF867 should now appear under Urvashi's tree, not Namisha's.

## Centre reassignment for a teacher

**Example:** "Move Mushahid AF475 from JNV Lucknow to JNV Medak"

1. **Decisions tab** — add a row noting the centre move and rationale.
2. **Reconciliation tab** — find the AF475 record. Change `alloc_cc` to JNV Medak. Status should become `centre_reassigned` (named teacher's alloc cc differs from budget cc → action: update budget cc).
3. **Employee Master (Final) tab** — update `Final Centre / CC` to JNV Medak. Update `Changes Applied` to include "Centre reassigned".
4. **org_chart.html Centre Master tab** — Mushahid moves from one centre's row to another.

## Role change (non-teaching → teaching, or vice versa)

**Example:** "AF676 Amar Nagpal: L&D → Teacher Physics at JNV Ujjain 2"

1. **Decisions tab** — note the role change explicitly.
2. **Employee Master (Final) tab** — update `Final Role` from "L&D / Non-Teaching" to "Teacher - Physics". Update `Role Source` to "Recruitment override". Update `Level (Teaching)` based on centre (read from cell-colour map in APPROACH.md or the Rules tab). Set `Final Centre / CC` to JNV Ujjain 2. `Changes Applied` should include "Role changed to teaching".
3. **Teacher Alloc replica (Src tab)** — confirm the person appears there at the new centre with the right subject. If the source recruitment sheet shows them differently, that's a Data Issue too.
4. **Reconciliation tab** — they should now appear with appropriate status.
5. **Vacancy List tab** — if this fills a teaching vacancy at JNV Ujjain 2, mark it filled.

## New vacancy

**Example:** "We need to hire an APM for Punjab cluster"

1. **Vacancy List tab** — add a row: Type (APM), Subject/area (Punjab cluster), Centre/cluster, Reporting manager, Notes.
2. **Decisions tab** — log the decision to open the vacancy with rationale.

## Vacancy filled

**Example:** "Hired Reshu for the Punjab APM role; she's AF863"

1. **Vacancy List tab** — remove or mark filled.
2. **Employee Master (Final) tab** — confirm AF863's row reflects the new role.
3. **Decisions tab** — log the hire and confirm the reporting line.

## New rule or convention

**Example:** "Treat Foundation Mathematics and Mathematics as the same subject"

1. **Rules tab** — add the alias / convention row.
2. **APPROACH.md** — add to the Centre aliases or Rules section as appropriate.
3. Re-run the build pipeline so the alias is applied across all derived data.

## New clarification

**Example:** "We're not sure who Pooja Bhandari's team reports to now that her manager exited"

1. **Open Questions tab** — add a row with the question, who's affected, who can answer, status.
2. Don't make up an answer in the workbook — leave the affected rows in `Employee Master (Final)` as-is until the question is answered, but flag them in `Changes Applied` with "Pending clarification".

## Data quality issue

**Example:** "The recruitment sheet has Ankit listed twice at JNV Lucknow"

1. **Data Issues tab** — add a row: location (sheet + tab + row), description, suggested fix, status (open / fixed in source).
2. Don't fix it in the source sheet (those are read-only). Note the workaround applied in our workbook in the Decisions tab.

## Centre merger / alias

**Example:** "JNV Odisha 2 is the same as JNV Puri — use JNV Puri everywhere"

1. **Rules tab** — add to the Centre aliases section.
2. **APPROACH.md** — update the Centre aliases table.
3. Re-run the build pipeline. The normalisation should propagate through `Centre Master`, `Reconciliation`, `Vacancy List`, and the HTML.

## Multiple changes in one session

If the user's prompt contains several changes, batch them:

1. List out each change for confirmation before applying ("Here's what I'm going to update — does this look right?").
2. Apply all of them in the workbook tabs.
3. Regenerate downstream views once at the end (HTML, Reconciliation, Vacancy List, Employee Master Final).
4. One Change Log entry in APPROACH.md summarising the batch.
5. One round of Drive uploads at the end.

This is much cleaner than doing them one at a time.
