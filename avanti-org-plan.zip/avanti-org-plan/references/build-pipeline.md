# Build Pipeline

The reconciliation and outputs are built up in stages from the source xlsx files. Each stage produces a JSON intermediate that subsequent stages consume. The Python scripts live in `/home/claude/build/`.

Source xlsx files at session start (downloaded from the source Google Sheets via gspread or copied from earlier session):
- `/home/claude/teacher_alloc.xlsx` — from the Teacher Recruitment sheet, "Latest 16 Apr" tab
- `/home/claude/personnel.xlsx` — from the Personnel Budget sheet, "FY27 - Consolidated Personnel -" tab

If these aren't already present at the start of a session and the workbook tabs `Src - Teacher Alloc` and `Src - Personnel Budget` aren't enough, re-export them from the source Sheets.

## Pipeline order

1. **`step1_centre_master.py`** → `centre_master.json`
   - Parses 53 centres with type / system / category / owner / course / plan
   - Sets `needs_apc` flag based on whether the recruitment sheet's APC column has a name or is "NA"

2. **`step2_teacher_master.py`** → `teacher_master.json`
   - Parses teachers from "Latest 16 Apr" tab
   - Reads cell fill colours to derive each teacher's level (JEE Mains Plus, NEET, etc.) — colour map is in APPROACH.md and the Rules tab

3. **`step3_match_af_ids.py`** → `teacher_master_v2.json`
   - Backfills AF IDs by matching teacher names against the personnel sheet
   - Produces ~197 teacher records

4. **`step4_employee_master.py`** → `employee_master.json`
   - Reads all 445 personnel rows
   - Applies all RM overrides from the Decisions tab
   - This is where the override logic lives — the `rm_revised` field on each person is the layered output

5. **Reconciliation logic** → `teachers_reconciled_v2.json`
   - Cross-references teacher allocations against the personnel sheet
   - Assigns one of 8 statuses: `in_budget`, `hire_needed_with_budget`, `centre_reassigned`, `needs_budget_row`, `hire_needed_no_budget`, `tbh_excess_remove`, `no_alloc`, `vendor_no_budget_needed`

6. **HR pipeline** → `hr_tbhs.json`
   - Compiles open positions (priority TBHs, non-teaching vacancies, teaching vacancies)
   - 95 open positions in total at last build

7. **Output generation**:
   - Builds `org_chart.html` — 7 tabs (Akshay's Tree, Vandana's Tree, Centre Master, Teachers Audit, Budget Corrections, Vacancy List, Unassigned)
   - Builds `avanti_workbook.xlsx` — 12 tabs (README, Decisions, Rules, Open Questions, Data Issues, Employee Master Final, Reconciliation, Vacancy List, plus 4 Src replicas)

## When to re-run what

- Changed an RM only (non-teacher) → re-run step 4, then output generation
- Changed a teacher's centre → re-run reconciliation logic, step 4, output generation
- Changed a rule or alias → re-run the whole pipeline from step 1
- Just added a Decision/Open Question/Data Issue row (no structural change) → only re-run output generation

## Cell colour → Teacher level map

Read directly from the recruitment sheet cell fills (also in Rules tab and APPROACH.md):

| Hex | Level | Short |
|---|---|---|
| FF0000FF | JEE Mains Plus | JM+ |
| FF00FFFF | JEE Advanced | Adv |
| FF00FF00 | JEE Main | JM |
| FFFF00FF | NEET | NEET |
| FFFF9900 | MBBS | MBBS |
| FF980000 | CET | CET |
| FF274E13 | Foundation | Fnd |
| FFFFFF00 | Yellow = substitute / training-team teacher; inherits centre's primary level |

## Reconciliation status reference

| Status | Meaning | Action |
|---|---|---|
| `in_budget` | Alloc cc matches budget cc | None — correct |
| `hire_needed_with_budget` | Subject gap; budget TBH already at centre | Hire — budget OK |
| `centre_reassigned` | Named teacher's alloc cc differs from budget cc | Update budget cc |
| `needs_budget_row` | Allocated FTE but no budget row | Add budget row |
| `hire_needed_no_budget` | Subject gap with no budget slot | Add budget + hire |
| `tbh_excess_remove` | Budget TBH at centre with no subject gap | Delete or reallocate |
| `no_alloc` | Person budgeted but not allocated to any centre | Investigate (exit / leave / realloc) |
| `vendor_no_budget_needed` | External contractor | None — vendor |

## Role priority

When a person appears in multiple sources:
1. **PM/SPM/APM mapping** = current role (highest priority)
2. **Teacher recruitment allocation** = current role
3. **Personnel budget designation** = fallback role

This prevents misclassifying ops people as teachers when their AF appears in multiple sheets.
