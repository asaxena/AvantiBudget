# Workbook Schema

The workbook (`avanti_workbook.xlsx`) has 12 tabs. Each one has a specific purpose and column layout. Read this when you need to know exactly which column to update.

## Tab order and purpose

| # | Tab | Purpose | Edits land here when... |
|---|---|---|---|
| 1 | README | Purpose, source links, snapshot date | Source sheets change, methodology shifts |
| 2 | Decisions | Every RM override / structural change with rationale & source | Any override is applied (always log here) |
| 3 | Rules | Interpretation logic in plain English | New rule, alias, convention emerges |
| 4 | Open Questions | Clarifications pending | Can't resolve something without input |
| 5 | Data Issues | Findings to fix in source sheets | Source-sheet quality problem found |
| 6 | Employee Master (Final) | Cleaned view: every person, original vs final RM/centre/role | Any change to a specific person |
| 7 | Reconciliation | Flat dump of all reconciled teacher records | Teacher centre / status changes |
| 8 | Vacancy List | All open positions | Vacancy opened, filled, or moved |
| 9 | Src - Centre Master | Source replica | Source Centre Master sheet refreshed |
| 10 | Src - PM-SPM-APM | Source replica | Source PM/SPM mapping refreshed |
| 11 | Src - Teacher Alloc | Source replica with cell-colour-derived levels | Source Teacher Recruitment sheet refreshed |
| 12 | Src - Personnel Budget | Source replica | Source Personnel Budget sheet refreshed |

The four `Src -` tabs are literal replicas of the source Google Sheets. They're never hand-edited; they're refreshed from source. Their purpose is to give a snapshot of what the source data looked like at the time of the workbook build, so you can audit any decision against it.

## Tab columns

### README (tab 1)
Free-form rows. Not structured by columns. Update narrative content as needed.

### Decisions (tab 2)
| Col | Purpose |
|---|---|
| Date | When the decision was made |
| AF ID | Person / TBH ID affected |
| Person Name | Display name |
| Change Type | RM override, Centre reassignment, Role change, Hire, Exit, etc. |
| From | Previous value |
| To | New value |
| Rationale | Why this change |
| Source | Where the instruction came from (conversation, email, source sheet update, etc.) |

Always append; never overwrite. The Decisions tab is the audit log.

### Rules (tab 3)
| Col | Purpose |
|---|---|
| Rule | Short name |
| Description | Plain-English explanation |
| Applies to | Which entities the rule affects (teachers, centres, all employees, etc.) |

### Open Questions (tab 4)
| Col | Purpose |
|---|---|
| Question | What needs clarification |
| Affected | AF IDs / centres / processes affected |
| Owner | Who needs to answer |
| Status | Open / Answered / Stale |

### Data Issues (tab 5)
| Col | Purpose |
|---|---|
| Source | Which source sheet has the issue |
| Location | Tab + row (or cell reference) |
| Description | What's wrong |
| Suggested fix | What should change |
| Status | Open / Workaround applied / Fixed in source |

### Employee Master (Final) (tab 6)
This is the central tab. 13 columns. Frozen panes at column C (so AF / Name / Status are always visible).

| Col | Purpose |
|---|---|
| AF / TBH ID | Join key |
| Name | Display name |
| Status | Active / Long Leave / TBH / Exit |
| Final Role | Teacher - [subject] / SPM / PM / APM / Non-Teaching / Vacancy |
| Role Source | Personnel sheet / PM-SPM-APM mapping / Teacher recruitment / Recruitment override |
| Designation | Free text from personnel sheet |
| Function | Free text from personnel sheet |
| Level (Teaching) | JM+ / Adv / JM / NEET / MBBS / CET / Fnd (only for teachers) |
| Final RM (after corrections) | Reporting manager after all overrides applied |
| Original RM (Personnel sheet) | What the personnel sheet shows (audit trail) |
| Final Centre / CC | Centre after any reassignment |
| Original Centre / CC | What the personnel sheet shows |
| Changes Applied | Human-readable summary of what changed (RM changed, Centre reassigned, Role changed, Pending clarification, etc.) |

Conditional formatting:
- Status column: green for Active, orange for Long Leave, red for TBH, grey for Exit
- Role column: shaded by role type
- Final RM column: orange highlight if differs from Original RM
- Final Centre column: orange highlight if differs from Original Centre
- Changes Applied column: yellow highlight if not "—"

### Reconciliation (tab 7)
Flat dump of all reconciled teacher records (~262 rows). Used for the Teachers Audit and Budget Corrections views in the HTML.

Key columns: AF ID, Name, Subject, Level, Alloc Centre, Budget Centre, Status (one of 8 reconciliation statuses), Action.

### Vacancy List (tab 8)
~95 rows of all open positions. Three categories: priority TBHs, non-teaching vacancies, teaching vacancies.

Columns: Type, Subject/Area, Centre, Reporting Manager, Notes, Priority.

### Src tabs (9-12)
Refer to the source Google Sheets. Don't edit directly; refresh from source when needed.

## Column ordering convention

Within each tab, the most-referenced columns come first. Audit columns (Original values) come after the Final values. Notes / metadata columns come last. This makes the tabs scannable at a glance without horizontal scrolling.
