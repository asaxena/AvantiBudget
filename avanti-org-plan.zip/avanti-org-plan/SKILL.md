---
name: avanti-org-plan
description: Update the Avanti Fellows FY27 organizational plan — RM overrides, role corrections, centre reassignments, vacancy changes, new clarifications, or data issues. Trigger on phrases like "update Avanti Org Plan", "update the org plan", "update the workbook", "fix Akshay's tree", "fix Vandana's tree", "change RM for an AF ID", "so-and-so now reports to someone else", "add a clarification", "regenerate the org chart", or any reference to Avanti Fellows org structure, the GitHub repo asaxena/AvantiBudget, or the files avanti_workbook.xlsx, index.html, or APPROACH.md. Also trigger when the user mentions reconciling teachers against the recruitment sheet, fixing the personnel budget, or when AF IDs come up in a planning context. Use this even if the user does not explicitly say "skill" — any work touching the org plan workbook or chart should run through this protocol so the workbook stays the source of truth.
---

# Avanti FY27 Org Plan — Update Protocol

This skill captures the workflow for updating the Avanti Fellows FY27 organisational plan. The plan lives in a GitHub repo served via GitHub Pages; the workbook is the source of truth, the HTML chart is a derived view served as `index.html`, and APPROACH.md is the running methodology document.

**GitHub repo (source of truth):** `asaxena/AvantiBudget`
- Repo: https://github.com/asaxena/AvantiBudget
- Live site: https://asaxena.github.io/AvantiBudget/
- Raw files: `https://raw.githubusercontent.com/asaxena/AvantiBudget/main/<filename>`

**Files maintained:**
- `avanti_workbook.xlsx` — 13-tab workbook, source of truth
- `index.html` — visual org chart, served as the GitHub Pages root
- `APPROACH.md` — methodology, rules, decision history, change log

The HTML is read-only — all edits happen in chat via this skill. The HTML re-renders from the workbook each build.

## Session Start — always do this first

Even if the conversation summary at the top of the chat seems to cover what's going on, the summary may be incomplete or stale. The GitHub repo is authoritative. Do this every time:

1. **Download the latest three files from GitHub raw URLs:**
   ```bash
   curl -s -o /home/claude/build/avanti_workbook.xlsx https://raw.githubusercontent.com/asaxena/AvantiBudget/main/avanti_workbook.xlsx
   curl -s -o /home/claude/index.html https://raw.githubusercontent.com/asaxena/AvantiBudget/main/index.html
   curl -s -o /home/claude/build/APPROACH.md https://raw.githubusercontent.com/asaxena/AvantiBudget/main/APPROACH.md
   ```
   Raw URLs don't go through the API and aren't rate-limited the way the GitHub API is.

2. **Read APPROACH.md in full.** It contains the complete methodology, source file locations, rules, aliases, the cell-colour-to-level map, and the change log. Everything needed to make a sensible update is in there.

3. **Read the workbook tabs in this order** to load decision context:
   - **README** — purpose and source links
   - **Decisions** — every RM override and structural change made so far, with rationale
   - **Rules** — interpretation logic (priority order, aliases, APC rule, cell-colour map)
   - **Open Questions** — what's still pending clarification
   - **Data Issues** — known data-quality findings
   - **Employee Master (Final)** — current state of every person with original vs final RM/centre

4. **Skim the source replicas** if the user's request touches teachers, centres, or budget:
   - `Src - Centre Master`, `Src - PM-SPM-APM`, `Src - Teacher Alloc`, `Src - Personnel Budget`

5. **Only then** start the user's task. Don't guess at structure from memory — the workbook is the ground truth.

The original Google Sheets (Centre Master, PM/SPM mapping, Teacher Recruitment, Personnel Budget) are **read-only**. Never modify them. All changes layer on top in the workbook. Source URLs are listed in APPROACH.md and in the workbook README tab. The `Src -` tabs in the workbook are snapshot replicas of those sheets at the time of last build.

## Apply the change

Map the user's request to the right tab. The workbook is structured so that every kind of change has a home:

| User request | Update this tab |
|---|---|
| Change someone's RM ("X now reports to Y") | `Decisions` (add row with rationale) and `Employee Master (Final)` (update the person's row) |
| Move a person to a different centre | `Decisions` and `Employee Master (Final)`; if it's a teacher, also `Reconciliation` |
| Change someone's role (e.g. APM → Teacher) | `Decisions` and `Employee Master (Final)` |
| New rule or convention | `Rules` |
| New clarification needed | `Open Questions` |
| Data-quality finding in a source sheet | `Data Issues` |
| Mark a vacancy filled / new vacancy | `Vacancy List` |
| Centre alias / merger | `Rules` (alias entry) and propagate everywhere |

Always add the change to the `Decisions` tab when it's an override of a source-sheet value, with a short rationale and the source (which sheet or which earlier conversation prompted it). This builds the audit trail.

For detailed worked examples of common change types, see `references/change-types.md`.

## Regenerate downstream views

After updating the workbook, regenerate everything downstream so the views stay consistent:

1. **Regenerate `Reconciliation` tab** (if the change affects teachers — RM moves of non-teachers don't need this).
2. **Regenerate `Vacancy List` tab** (if a vacancy was filled, opened, or moved).
3. **Regenerate `Employee Master (Final)` tab** (this should already be done as part of applying the change, but rerun the build to make sure status/role/changes columns are accurate).
4. **Regenerate `org_chart.html`** — the HTML is a function of the workbook. Don't hand-edit it.

The build pipeline lives at `/home/claude/build/`. The general flow is documented in APPROACH.md under "Build pipeline". For a quick reference of the JSON intermediates and the order to run them, see `references/build-pipeline.md`.

## Update APPROACH.md

This is easy to forget but important. APPROACH.md is the running record:

- Bump the **Last updated** date at the top.
- If a new rule or convention emerged, add it to the relevant section (Rules / Methodology / Cell colour map / Centre aliases).
- Append a brief entry to the **Change Log** at the bottom: date, one-line summary of what changed, which files were updated.

This means when a future session reads APPROACH.md, it sees a clear history of what's happened.

## Session End — present files for the user to commit

Once all three files are updated locally (`avanti_workbook.xlsx`, `index.html`, `APPROACH.md`), present them to the user via `present_files` so they can download and commit to the GitHub repo.

The user commits the files to https://github.com/asaxena/AvantiBudget manually (drag-and-drop in the GitHub web UI works, or `git push` from a local clone). GitHub Pages then auto-deploys to https://asaxena.github.io/AvantiBudget/ within a minute or two.

There is no automated push from this skill — committing is a deliberate user action so they can review changes before they go live. Just make sure all three files are in `/mnt/user-data/outputs/` and call `present_files` on them.

## Output expectations

A complete session ends with:
1. The user has confirmation of what changed (a clear summary of which decisions were applied, which tabs were updated, which downstream views regenerated).
2. All three updated files are presented via `present_files` for the user to commit to the GitHub repo.
3. APPROACH.md change log has a new entry with today's date.

## Reference files

- `references/change-types.md` — detailed worked examples for the common kinds of changes (RM override, centre reassignment, role change, new vacancy, new rule, data issue, etc.)
- `references/build-pipeline.md` — the JSON intermediates and Python build steps in order
- `references/workbook-schema.md` — column layout and conventions for each of the 12 tabs
